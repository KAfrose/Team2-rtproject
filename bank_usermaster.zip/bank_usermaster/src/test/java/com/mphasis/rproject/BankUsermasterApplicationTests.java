package com.mphasis.rproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankUsermasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
