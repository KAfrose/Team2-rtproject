package com.mphasis.rproject.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="transaction_details")
public class TransactionDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private String transaction_id;
	private Date dot;
	private String transaction_type;
	private String amount;
	private String from_Account;
	private String to_Account;
	
	public TransactionDetails() {}

	
	public TransactionDetails(String transaction_id, Date dot, String transaction_type, String amount,
			String from_Account, String payee_Id) {
		super();
		this.transaction_id = transaction_id;
		this.dot = dot;
		this.transaction_type = transaction_type;
		this.amount = amount;
		this.from_Account = from_Account;
		this.to_Account = to_Account;
		
	}
	


	public String getTransaction_id() {
		return transaction_id;
	}


	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}


	public Date getDot() {
		return dot;
	}


	public void setDot(Date dot) {
		this.dot = dot;
	}


	public String getTransaction_type() {
		return transaction_type;
	}


	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	


	public String getFrom_Account() {
		return from_Account;
	}


	public void setFrom_Account(String from_Account) {
		this.from_Account = from_Account;
	}


	public String getTo_Account() { 
		return to_Account;
	}


	public void setTo_Account(String to_Account) {
		this.to_Account = to_Account;
	}


	@Override
	public String toString() {
		return "TransactionDetails [transaction_id=" + transaction_id + ", dot=" + dot + ", transaction_type="
				+ transaction_type + ", amount=" + amount + ", from_Account=" + from_Account + ",to_Account=" + to_Account 
				+ "]";
	}


	
	
}
