import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AccountService } from '../account.service';



@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  accounts: any;
  account:any=null;
  accountForm: any;

  constructor(private fb: FormBuilder, private as: AccountService) {
    this.accountForm = this.fb.group({
      acc_number: ['']
    });
  }

  ngOnInit(): void {
    // this.fnSubmit();
  }
  get form() {
    return this.accountForm.controls;
  }

  fnSubmit() {
    var acc_number=this.accountForm.controls.acc_number.value;
    
    console.log("finding account for accnumber:"+acc_number);
    this.as.findAccountByAcN(acc_number).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      //this.accountForm.patchValue(data);
      this.account = data;
      

    });
  }
}
