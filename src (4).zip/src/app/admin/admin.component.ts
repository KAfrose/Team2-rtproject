import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { User } from '../user';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  adminForm: any;
  transactions: any;

  constructor(private fb: FormBuilder,private as: AdminService,private router:Router) { 
    this.adminForm = this.fb.group({
      TransactionId: [''],
      Amount: [''],
      DOT: [''],
      TransactionType: [''],
      AccountNumber: [''],
      PayeeId: [''],
    });
  }
  get form() {
    return this.adminForm.controls;
  }
  ngDoCheck(): void {
    var str = localStorage.getItem("user");
    var user: User = <User><any>JSON.parse(str);
    var role=user.role;
    if(role!="Admin")
    {
      alert("All Transaction details can be seen only by admin");
      this.router.navigateByUrl('/(col3:home)');
    }

  }
  ngOnInit(): void {
    this.getAllTransactions();
  }
  getAllTransactions() {
    this.as.getAllTransactions().subscribe((data) => {
      console.log(data);
      this.transactions = data;
    });
  }

}
