import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {
  url:string='http://localhost:8080/payee/';

  constructor(private http:HttpClient) { }
  addPayee(payee:any)
  {
    return this.http.post(this.url,payee);
  }

  findPayeeById(payeeId:string)
  {
    return this.http.get(this.url+payeeId);
  }
}

  
