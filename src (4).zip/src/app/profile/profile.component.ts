import { PlatformLocation } from '@angular/common';
import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ProfileService } from '../profile.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, DoCheck {
  profileForm: any;


  constructor(private fb: FormBuilder, private ps: ProfileService, private us:UserService ,location: PlatformLocation, private router: Router) {
    this.profileForm = this.fb.group({
      userName: [''],
      password: [''],
      firstName: [''],
      lastName: [''],
      city: [''],
      mobile: [''],
      emailAddress: [''],
      role:['']

    });
    console.log("form group is created")
  }
  ngDoCheck(): void {
    var str = localStorage.getItem("user");
    var user: User = <User><any>JSON.parse(str);
    console.log('patching user: ' + str);
    this.profileForm.setValue(user);
     //this.profileForm.controls.userName.patchValue(user.userName);

  }
  get form() {
    return this.profileForm.controls;
  }


  ngOnInit(): void {
  }
  
  fnUpdate()
  {
    var user=this.profileForm.value;
    this.us.modifyUser(user).subscribe((data)=>{
      console.log(data);
    })
  }
}
