import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit,DoCheck {
name:any;
  constructor() { }
  ngDoCheck(): void {
    //check if local storage "user" is not null, then logged in. else, not logged in
    this.name=localStorage.getItem("userName");

  }

  ngOnInit(): void {
  }

}
