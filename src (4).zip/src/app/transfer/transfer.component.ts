import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

import { AccountDetails } from '../account-details';
import { AccountService } from '../account.service';
import { Payee } from '../payee';
import { PayeeService } from '../payee.service';
import { TransactionDetails } from '../transaction-details';

import { TransferService } from '../transfer.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})

export class TransferComponent implements OnInit {

  transferForm: any;
  constructor(private fb: FormBuilder, private ts: TransferService, private router: Router, private as: AccountService, private ps: PayeeService) {
    this.transferForm = this.fb.group({
      acc_number: [''],
      payeeId: [''],
      dot: [''],
      transactionType: ['online'],
      amount: [''],
    });
  }

  ngOnInit(): void {
  }
  get form() {
    return this.transferForm.controls;
  }
  fnfundTransfer() {
    var transactionDetails = new TransactionDetails();
    var accountDetails: AccountDetails = new AccountDetails();
    var payeeId = this.transferForm.controls.payeeId.value;
    var payee: Payee = new Payee();


    //find account details object based on account num ber (using service subscribe)
    var acc_number = this.transferForm.controls.acc_number.value;
    console.log("fnfundTransfer: accnumber is " + acc_number);
    this.as.findAccountByAcN(acc_number).subscribe((data) => {
      console.log("Found account object is " + JSON.stringify(data));
      accountDetails = <any>data;

      transactionDetails.accountDetails = accountDetails;

      this.ps.findPayeeById(payeeId).subscribe((data) => {
        console.log("Payee found: " + JSON.stringify(data));
        payee = <any>data;


        transactionDetails.payee = payee;
        transactionDetails.dot = new Date();
        transactionDetails.transaction_type = 'online';

        transactionDetails.amount = this.form.amount.value;
        //accountDetails.balance-=this.form.amount.value;

        this.ts.fundTransfer(transactionDetails).subscribe((data)=>{
          console.log("Submitting the transaction objecgt as : "+JSON.stringify(transactionDetails));
          console.log("Obtained response as : "+JSON.stringify(data));
          var amount=transactionDetails.amount;
          this.as.updateBalance(acc_number,amount).subscribe((data)=>{
            console.log("After updating balance is"+JSON.stringify(accountDetails));
          })
        })

      });
    })





    //under construction
    // this.ts.fundTransfer(transactionDetails).subscribe(data=>{
    //   console.log(data);
    // });
  }




}
