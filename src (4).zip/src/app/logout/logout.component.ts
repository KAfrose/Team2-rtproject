import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit, DoCheck {

  constructor(private router:Router) { }
  ngDoCheck(): void {

    localStorage.removeItem("user");
 //redirtect to menu
//  this.router.navigateByUrl('/(col3:home)');

  }
  ngOnInit(): void {
    
  }
  
  //window.location.reload();

}
