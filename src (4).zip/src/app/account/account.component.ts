import { Route } from '@angular/compiler/src/core';
import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from '../account.service';
import { User } from '../user';



@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit,DoCheck {
  accounts: any;
  account:any=null;
  accountForm: any;
  user : User=new User();
  constructor(private fb: FormBuilder, private as: AccountService,private router:Router) {
    this.accountForm = this.fb.group({
      acc_number: ['']
    });
  }

  ngOnInit(): void {
    // this.fnSubmit();
  }
  ngDoCheck(): void {
    var str = localStorage.getItem("user");
    console.log(str);
    this.user = <User><any>JSON.parse(str);
    var name:string;;
    if(str==null)
    {
     // alert("Please Login to access the services");
    //  this.router.navigateByUrl('/(col3:login)');
    }else
    {
      name=this.user.userName;
    }

  }
  get form() {
    return this.accountForm.controls;
  }

  fnSubmit() {
    var acc_number=this.accountForm.controls.acc_number.value;
    
    console.log("finding account for accnumber:"+acc_number);
    this.as.findAccountByAcN(acc_number).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      //this.accountForm.patchValue(data);
      this.account = data;
      

    });
  }
}
