import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PayeeService } from '../payee.service';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  payeeForm: any;
  constructor(private fb: FormBuilder, private ps: PayeeService) {
    this.payeeForm = this.fb.group({
      payeeId: [''],
      bankName: [''],
      acc_number: [''],
      payeeName: [''],
      userName: ['']
    });
  }

  ngOnInit(): void {
  }
  get form() {
    return this.payeeForm.controls;
  }
  fnAddPayee() {
    this.ps.addPayee(this.payeeForm.value).subscribe(data => {
      console.log(data);
    })
    // this.router.navigateByUrl('/(col3:login)');


  }

}
