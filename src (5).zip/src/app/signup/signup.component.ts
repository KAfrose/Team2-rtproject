import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  loading:boolean=false;
  signupForm:any;
  gotp:any;
  otpError:any;
  constructor(private fb:FormBuilder, private us:UserService,private router:Router) {
    this.signupForm=this.fb.group({
      userName:['',Validators.required],
      password:['',Validators.required],
      cpassword:['',Validators.required], 
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      city:[''],
      mobile:['',[Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      emailAddress:['',[Validators.required, Validators.email]],
      role:[''],
      generatedOtp:[''],
      enteredOtp:['']
    },{ 
       validator: this.ConfirmedValidator('password','cpassword')
    });
    // 

   }

  ngOnInit(): void {
    // this.signupForm.controls.generatedOtp.value='0000';
  }
  get f(){
    return this.signupForm.controls;
  }
 ConfirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}

  addUser()
  {
    this.loading=true;
    var eotp=this.signupForm.controls.enteredOtp.value;
    // alert('comparing '+eotp+' with '+this.gotp);
   // alert('adding...');

   if(eotp!=this.gotp)
   {
    this.otpError="Entered otp is invalid";
     return;
   }
    console.log(this.signupForm.value);
    this.us.addUser(this.signupForm.value).subscribe(data=>{
      console.log(data);
    setTimeout(() => {

    this.router.navigateByUrl('/(col3:login)');
      
    }, 5000);
    this.loading=false;

 
   
    
 });
  }
  

  fnGenerateOtp()
  {
    //under construction
    var emailAddress=this.signupForm.controls.emailAddress.value;
    console.log(emailAddress);
    this.us.generateOtp(emailAddress).subscribe((data)=>{
      // console.log(data);
      // this.signupForm.controls.generatedOtp.value=data;
     this.gotp=data;      
    });
    // this.signupForm.controls.generatedOtp.value=this.gotp;
  }
}
