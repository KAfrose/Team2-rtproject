import { Payee } from './payee';

describe('Payee', () => {
  it('should create an instance', () => {
    expect(new Payee()).toBeTruthy();
  });
});
