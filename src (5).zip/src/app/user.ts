// private String userName;
// 	private String password;
// 	private String firstName;
// 	private String lastName;
// 	private String mobile;
// 	private String city;
// 	private String emailAddress;
// 	private String role;


export class User {
    userName:string;
    password:string;
    firstName:string;
    lastName:string;
    mobile:string;
    city:string;
    emailAddress:string;
    role:string;
}
