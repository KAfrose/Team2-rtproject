import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit, DoCheck {

  status='login';
  constructor() { }
  ngDoCheck(): void {
    //check if local storage "user" is not null, then logged in. else, not logged in
    var user=localStorage.getItem("user");
    //alert('Menu component user is '+user);
    if(user==null)
    {
      //alert('not logged in');
      this.status='login';
    }
    else
    {
      //alert('logged in')
      this.status='logout';
    }
  }

  ngOnInit(): void {
  }



}
