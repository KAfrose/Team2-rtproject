import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { PayeeService } from '../payee.service';
import { User } from '../user';


@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  payeeForm: any;
  user:any;
  name:String;
  constructor(private fb: FormBuilder, private ps: PayeeService) {
    this.payeeForm = this.fb.group({
      payeeId: ['',[Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      bankName: [''],
      acc_number: ['',[Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      payeeName: [''],
      userName: ['']
    },{validators:this.payeeIdValidator()});
  }
   payeeIdValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.payeeId.errors && !formGroup.controls.payeeId.errors.payeeIdValidator)
        return;
      var status = false;
      var payeeId = formGroup.controls.payeeId.value;
      //alert(bid.substring(0,1));
      if (payeeId.substring(0, 1) != 'P') {
        status = true;
      } else {
        var num = payeeId.substring(1);
        if (isNaN(num))
          status = true;
      }
      if (status)
        formGroup.controls.payeeId.setErrors({ 'payeeIdValidator': true });
      else
        formGroup.controls.payeeId.setErrors(null);
    }
  }
   ngDoCheck(): void {
    //check if local storage "user" is not null, then logged in. else, not logged in
    this.name=localStorage.getItem("userName");
     var str = localStorage.getItem("user");
    console.log(str);
    this.user = <User><any>JSON.parse(str);
    var name:string;;
    // if(str==null)
    // {
    //  // alert("Please Login to access the services");
    // //  this.router.navigateByUrl('/(col3:login)');
    // }
    if(str!=null)
    {
      name=this.user.userName;
    }


  }

  ngOnInit(): void {
  }
  get form() {
    return this.payeeForm.controls;
  }
  fnAddPayee() {
    this.ps.addPayee(this.payeeForm.value).subscribe(data => {
      console.log(data);
    })
    // this.router.navigateByUrl('/(col3:login)');


  }

}
